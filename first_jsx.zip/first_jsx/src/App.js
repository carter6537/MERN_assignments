import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';


class App extends Component {
  render() {
    return (
      <div>
        <h1>Hello Dojo!</h1>
        <h2>Things I need to do:</h2>
        <ul>
          <li>Learn React</li>
          <li>Climb Mt. Everest</li>
          <li>Run a marathon</li>
          <li>Feed The dogs</li>
        </ul>
      </div>
    );
  }
}

export default App;
